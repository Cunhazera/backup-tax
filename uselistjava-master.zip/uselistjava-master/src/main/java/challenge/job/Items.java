package challenge.job;

import java.util.ArrayList;

public class Items {
	
	public static ArrayList<String> itemsList() {
		ArrayList<String> items = new ArrayList<String>();
		items.add("Pen");
		items.add("Docker");
		items.add("Container");
		items.add("Alcohol");
		items.add("Wood");
		items.add("Bread");
		items.add("Shuffle");
		items.add("Phone");
		items.add("Notebook");
		items.add("Umbrella");
		items.add("TV");
		items.add("Door");
		items.add("Bed");
		items.add("Sink");
		items.add("Food");
		items.add("Freak");
		items.add("Fast");
		
		return items;
	}

}
